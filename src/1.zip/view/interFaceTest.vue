<template>
    <div class="pageTest" :style="{ height: screenHeight - 20, width: screenWidth - 20 }">
        <div class="insidePage" :style="{ left: screenWidth/2 - 100 , top: screenHeight/2 - 100 }" @click="doAsk()">
            <!--honor 8     1080 -->
            <text>weex.env屏幕宽度:{{a}}</text>
            <!--honor 8     1794 -->
            <text>weex.env屏幕高度:{{b}}</text>
            <!--honor 8     750 -->
            <text>屏幕宽度:{{c}}</text>
            <!--honor 8     1245.833333333 -->
            <text>屏幕高度:{{d}}</text>
        </div>
    </div>
</template>
<style>
    .insidePage{
        position: absolute;
        width: 200px;height: 200px;
        background-color: #0088fb;
        /*border: 10px solid red;*/
    }
    .pageTest{
        margin-left: 10px;
        margin-top: 10px;
        background-color: cadetblue;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>
<script>
    import utils from '../assets/utils';
    const event = weex.requireModule('event');
    import { POST, GET } from '../assets/fetch';
    export default {
        data(){
            return {
                screenWidth:'',
                screenHeight:'',
                a:''
            }
        },
        created(){
            this.screenWidth = 750/weex.config.env.deviceWidth * weex.config.env.deviceWidth;
            this.screenHeight = 750/weex.config.env.deviceWidth * weex.config.env.deviceHeight;
            console.log(weex.config.env.deviceWidth)
            console.log(weex.config.env.deviceHeight);
            this.a = weex.config.env.deviceWidth;
            this.b = weex.config.env.deviceHeight;
            this.c = this.screenWidth;
            this.d = this.screenHeight;
        },
        methods:{
            doAsk(){
                GET('weex/member/review/test.jhtml',
                    function (data) {
                        if(data.type == 'success'){
                            utils.debug(data);
                        }else{
                            event.toast(data.content);
                        }
                    },
                    function (err) {
                        event.toast(err.content);
                    }
                )
            }
        }

    }
</script>
