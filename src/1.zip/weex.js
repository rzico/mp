const dom = weex.requireModule('dom');
const event = weex.requireModule('event');
const stream = weex.requireModule('stream');
const storage = weex.requireModule('storage');
const animation = weex.requireModule('animation');
export default {dom,event,stream,storage,animation};
