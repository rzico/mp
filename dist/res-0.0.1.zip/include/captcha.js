// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(75)
	)
	__vue_styles__.push(__webpack_require__(76)
	)

	/* script */
	__vue_exports__ = __webpack_require__(77)

	/* template */
	var __vue_template__ = __webpack_require__(79)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/ke/mopian/GitHubMoPian/mp/src/include/captcha.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-152ea986"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 75:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 28,
	    "color": "#bbbbbb"
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#bbbbbb",
	    "backgroundColor": "#D9141E"
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#bbbbbb",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderBottomWidth": 0,
	    "borderTopWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#D9141E"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#D9141E"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#D9141E"
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#D9141E"
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#D9141E"
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "backgroundColor": "#D9141E",
	    "borderRadius": 15,
	    "backgroundColor:active": "#bbbbbb",
	    "color:active": "#D9141E",
	    "backgroundColor:disabled": "#D9141E",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#D9141E",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 76:
/***/ (function(module, exports) {

	module.exports = {
	  "mtb50": {
	    "marginTop": 50,
	    "marginBottom": 60
	  },
	  "inputTextBox": {
	    "width": 530,
	    "position": "relative"
	  },
	  "inputText": {
	    "borderWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#999999",
	    "width": 80,
	    "height": 80,
	    "fontSize": 30,
	    "textAlign": "center",
	    "lineHeight": 80
	  },
	  "inputDiv": {
	    "flex": 1,
	    "alignItems": "center"
	  },
	  "input": {
	    "opacity": 0,
	    "width": 530,
	    "position": "absolute",
	    "height": 80,
	    "fontSize": 85
	  },
	  "captcha": {
	    "paddingLeft": 40,
	    "paddingRight": 40,
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "number": {
	    "fontSize": 48,
	    "color": "#000000",
	    "fontWeight": "600"
	  },
	  "content": {
	    "flexWrap": "wrap"
	  },
	  "mobile-title": {
	    "fontSize": 48,
	    "color": "#000000",
	    "flexWrap": "wrap"
	  },
	  "mobile-header": {
	    "marginTop": 150,
	    "height": 100,
	    "backgroundColor": "#ffffff",
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "status": {
	    "fontSize": 32,
	    "lineHeight": 60,
	    "borderBottomWidth": 0
	  }
	}

/***/ }),

/***/ 77:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _utils = __webpack_require__(78);

	var _utils2 = _interopRequireDefault(_utils);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var optionIndex = 0;
	var lastCaptchaLength = 0;
	var timer = null;
	exports.default = {
	    data: function data() {
	        return {
	            time: 59,
	            textList: ['', '', '', '', '', '']
	        };
	    },
	    props: {
	        title: { default: "验证码" },
	        captcha: { default: "" },
	        mobile: { default: "" },
	        status: { default: "点击重新发送" },
	        retry: { default: false }
	    },
	    beforeDestory: function beforeDestory() {
	        var _this = this;
	        if (_utils2.default.isNull(timer) == false) {
	            clearInterval(timer);
	            _this.time = 59;
	            timer = null;
	        }
	    },
	    created: function created() {
	        this.beginTimer();
	    },

	    methods: {
	        beginTimer: function beginTimer() {
	            var _this = this;
	            _this.retry = false;
	            if (_utils2.default.isNull(timer) == false) {
	                clearInterval(timer);
	                _this.time = 59;
	                timer = null;
	            }
	            timer = setInterval(function () {
	                _this.time = _this.time - 1;
	                if (_this.time < 1) {
	                    _this.endTimer();
	                }
	            }, 1000);
	        },
	        endTimer: function endTimer() {
	            var _this = this;
	            if (_utils2.default.isNull(timer) == false) {
	                clearInterval(timer);
	                _this.time = 59;
	                timer = null;
	            }
	            this.retry = true;
	        },
	        statusStyle: function statusStyle() {
	            if (this.retry) {
	                return "";
	            } else {
	                return "color:#ccc";
	            }
	        },
	        clear: function clear() {
	            this.captcha = "";
	            this.textList = ['', '', '', '', '', ''];
	        },
	        //            当用户输入数字时触发
	        captchaInput: function captchaInput(event) {
	            var _this = this;
	            //                判断删除还是输入  '大于' --> 删除
	            if (lastCaptchaLength > event.value.length) {
	                optionIndex--;
	                _this.textList[optionIndex] = '';
	            } else {
	                var a = event.value;
	                var b = a.substr(a.length - 1, 1);
	                console.log(event);
	                _this.textList[optionIndex] = b;
	                optionIndex++;
	            }
	            lastCaptchaLength = event.value.length;
	            //                当用户输完验证码后进行系统验证
	            if (lastCaptchaLength == 6) {
	                _this.captcha = event.value;
	                //                    _this.beginTimer();
	                _this.$emit("onEnd", this.captcha);
	            }
	        },
	        //            点击验证框时使隐藏的input获取焦点；
	        getFocus: function getFocus() {
	            this.$refs['captchRef'].focus();
	        },
	        send: function send() {
	            this.$emit("onSend", this.captcha);
	        }

	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 78:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	/**
	 * Created by zwwill on 2017/8/27.
	 */
	var resLocateURL = 'file://';
	var resRemoteURL = 'http://cdn.rzico.com/weex/';
	var dataURL = 'http://weex.rzico.com:8088/';

	var utilsFunc = {
	    initIconFont: function initIconFont() {
	        var domModule = weex.requireModule('dom');
	        domModule.addRule('fontFace', {
	            'fontFamily': "iconfont",
	            'src': "url('" + resLocateURL + "resources/fonts/iconfont.ttf')"
	        });
	    },

	    //获取本地资源
	    locate: function locate(url) {
	        var newUrl = resLocateURL + url;
	        return newUrl;
	    },

	    //获取远程资源
	    remote: function remote(url) {
	        var newUrl = resRemoteURL + url;
	        return newUrl;
	    },

	    //获取URL参数
	    getUrlParameter: function getUrlParameter(name) {
	        var url = weex.config.bundleUrl;
	        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	        var r = url.slice(url.indexOf('?') + 1).match(reg);
	        if (r != null) {
	            try {
	                return decodeURIComponent(r[2]);
	            } catch (_e) {
	                return null;
	            }
	        }
	        return null;
	    },
	    dayfmt: function dayfmt(value) {
	        var date = new Date(value);
	        var tody = new Date();
	        var m = tody.getDay() - date.getDay();
	        if (m < 1) {
	            return "今天";
	        }
	        if (m < 3) {
	            return "近三天";
	        }
	        if (m < 7) {
	            return "近七天";
	        }
	        return "七天前";
	    },
	    message: function message(_type, _content, _data) {
	        return {
	            type: _type,
	            content: _content,
	            data: _data
	        };
	    },

	    //判空
	    isNull: function isNull(value) {
	        if (value == null || value == undefined || value == '') {
	            return true;
	        } else {
	            return false;
	        }
	    },

	    //本地缓存查找多条数据。
	    findList: function findList(value, start, size, callback) {
	        var partevent = weex.requireModule('event'); //在ios无法识别出该语句，考虑弃用该方法
	        partevent.findList({
	            type: 'article',
	            keyword: value,
	            orderBy: 'desc',
	            current: start,
	            pageSize: size
	        }, callback);
	    },
	    save: function save(datatype, datakey, datavalue, datasort, datakeyword, callback) {
	        var partevent = weex.requireModule('event');
	        partevent.save({
	            type: datatype,
	            key: datakey,
	            value: datavalue,
	            sort: datasort,
	            keyword: datakeyword
	        }, callback);
	    },

	    //时间戳
	    timeChange: function timeChange(value) {
	        if (value.toString().length == 10) {
	            value = value * 1000;
	        }
	        var date = new Date(value);
	        var Y = date.getFullYear();
	        var m = date.getMonth() + 1;
	        var d = date.getDate();
	        var H = date.getHours();
	        var i = date.getMinutes();
	        var s = date.getSeconds();
	        if (m < 10) {
	            m = '0' + m;
	        }
	        if (d < 10) {
	            d = '0' + d;
	        }
	        if (H < 10) {
	            H = '0' + H;
	        }
	        if (i < 10) {
	            i = '0' + i;
	        }
	        if (s < 10) {
	            s = '0' + s;
	        }
	        var t = Y + '-' + m + '-' + d + ' ' + H + ':' + i + ':' + s;
	        // var t = Y + '-' + m + '-' + d;
	        return t;
	    },
	    thumbnail: function thumbnail(url, w, h) {
	        if (url.substring(0, 10) == "http://cdn") {
	            return url + "@" + w + "w_" + h + "h_1e_1c_100Q";
	        } else {
	            return url;
	        }
	    },

	    //获取文章URL地址
	    articleUrl: function articleUrl(template, id) {
	        return dataURL + "article/#/" + template + "?id=" + id;
	    }
	};

	exports.default = utilsFunc;
	module.exports = exports['default'];

/***/ }),

/***/ 79:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["captcha"]
	  }, [_c('div', {
	    staticClass: ["mobile-header"]
	  }, [_c('text', {
	    staticClass: ["mobile-title"]
	  }, [_vm._v(_vm._s(_vm.title))])]), _c('div', {
	    staticClass: ["content"]
	  }, [_c('text', {
	    staticClass: ["title"]
	  }, [_vm._v("我们已向")]), _c('text', {
	    staticClass: ["number"]
	  }, [_vm._v(_vm._s(_vm.mobile))]), _c('text', {
	    staticClass: ["title"]
	  }, [_vm._v("发送验证码短信，请查看短信并输入验证码")])]), _c('div', {
	    staticClass: ["flex-row", "inputTextBox", "mtb50"],
	    on: {
	      "click": function($event) {
	        _vm.getFocus()
	      }
	    }
	  }, [_c('input', {
	    ref: "captchRef",
	    staticClass: ["input"],
	    attrs: {
	      "type": "tel",
	      "maxlength": "6",
	      "autofocus": "true",
	      "value": (_vm.captcha)
	    },
	    on: {
	      "input": [function($event) {
	        _vm.captcha = $event.target.attr.value
	      }, _vm.captchaInput]
	    }
	  }), _vm._l((_vm.textList), function(item) {
	    return _c('div', {
	      staticClass: ["inputDiv"]
	    }, [_c('text', {
	      staticClass: ["inputText"]
	    }, [_vm._v(_vm._s(item))])])
	  })], 2), _c('div', {
	    staticClass: ["flex-center"]
	  }, [(_vm.retry) ? _c('text', {
	    staticClass: ["status", "primary"],
	    style: _vm.statusStyle(),
	    on: {
	      "click": function($event) {
	        _vm.send()
	      }
	    }
	  }, [_vm._v(_vm._s(_vm.status))]) : _c('text', {
	    staticClass: ["status", "gray"],
	    style: _vm.statusStyle()
	  }, [_vm._v(" " + _vm._s(_vm.time) + "秒后重新发送 ")])])])
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ })

/******/ });